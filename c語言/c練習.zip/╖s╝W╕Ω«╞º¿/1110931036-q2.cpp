#include<stdio.h>
#include<stdlib.h>

main (void)
{
	printf("\\""t�OTab�䪺�ĪG\n");
	system("pause");









} 
