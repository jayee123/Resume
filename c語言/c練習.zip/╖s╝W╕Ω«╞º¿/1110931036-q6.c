#include<stdio.h>
#include<stdlib.h>

void main(void)
{
	float in , out;
	puts("�п�J�ƭȡG");
	scanf("%f" , &in);
	out = in*in*in;
	printf("\n%.3f���T���謰%.3f" , in , out);
 } 
