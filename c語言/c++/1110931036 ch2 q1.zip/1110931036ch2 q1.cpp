#include<stdio.h>
#include<stdlib.h> 
main(void)
{
	printf("�z�n\n");
	system("pause"); 
}

